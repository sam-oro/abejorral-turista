<?php

    //Los otros jaja
/*$conn = new mysqli('localhost','root','','abejorral');
$URL = "http://localhost/abejorral-turista/";
$urlimagen="http://localhost/abejorral-turista/images/";*/

    //Servidor
 $conn = new mysqli('mysql1005.mochahost.com','hassorie_abejo','abejorral123','hassorie_abejorral2');
$URL = "http://contigoabejorral.com/";
$urlimagen="http://contigoabejorral.com/images/";


    //Samir
//$conn = new mysqli('localhost','root','','abejorral','33065');
//$URL = "http://localhost:8080/abejorral/";
//$urlimagen="http://localhost:8080/abejorral/images/";

?>